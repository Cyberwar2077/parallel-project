package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IBookDao;
import com.cg.entities.BookDetails;

@Service
@Transactional
public class BookServices implements IBookServices {

	@Autowired
	IBookDao iBookDao; 

	@Override
	public void createBook(BookDetails bookDetails) {
		iBookDao.createBook(bookDetails);
	}

	@Override
	public void updateBook(BookDetails newBookDetails) {
		iBookDao.updateBook(newBookDetails);
	}

	@Override
	public BookDetails displayBookDetails(BookDetails bookDetails) {
		return iBookDao.displayBookDetails(bookDetails);
	}

	@Override
	public void tableCreation() {
		iBookDao.tableCreation();
	}

}
