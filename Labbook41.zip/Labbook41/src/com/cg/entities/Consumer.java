package com.cg.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="consumers")
public class Consumer implements Serializable{
	
	@Id
	@NotEmpty(message="should not be empty")
	private int consumer_num;
	
	private String consumer_name;
	
	private String address;

	public int getConsumer_num() {
		return consumer_num;
	}

	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}

	public String getConsumer_name() {
		return consumer_name;
	}

	public void setConsumer_name(String consumer_name) {
		this.consumer_name = consumer_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Consumer [consumer_num=" + consumer_num + ", consumer_name=" + consumer_name + ", address=" + address
				+ "]";
	}
	
	
	
	
}
