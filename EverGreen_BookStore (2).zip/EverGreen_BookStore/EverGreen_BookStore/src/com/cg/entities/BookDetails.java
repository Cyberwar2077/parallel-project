package com.cg.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class BookDetails implements Serializable{
	@Id
	@GeneratedValue
	private int bookId;
	private Date publishDate;
	private int isbnNumber;
	private String title;
	private String author;
	private float averageRating;
	private int numberOfReviews;
	private float price;
	private String bookImage;
	private String description;
	private CategoryDetails category;
	
	public CategoryDetails getCategoryDetails(){
		return category;
	}
	public void getCategoryDetails(CategoryDetails category){
		this.category=category;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getBookImage() {
		return bookImage;
	}
	public void setBookImage(String bookImage) {
		this.bookImage = bookImage;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public BookDetails() {
		super();
	}
	public BookDetails( int isbnNumber, String title, String author,
			 float price, String bookImage, String description, CategoryDetails category) {
		super();
		this.publishDate = new Date();
		this.isbnNumber = isbnNumber;
		this.title = title;
		this.author = author;
		this.averageRating = 0;
		this.numberOfReviews = 0;
		this.price = price;
		this.bookImage = bookImage;
		this.description = description;
		this.category = category;
	}
	
}
