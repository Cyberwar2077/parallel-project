function validate(){
	var userName=f1.userName.value;
	var userpwd=f1.userPwd.value;
	var flag=false;
	if(userName==""||userName==null){
		document.getElementById('userErrMsg').innerHTML="* Please enter UserName.";
		flag=false;
	}else if(userpwd=="" || userpwd==null){
		document.getElementById('userErrMsg').innerHTML=" ";
		document.getElementById('usrPwdMsg').innerHTML="* Please enter User Password.";
		flag=false;
		
	}else{
		document.getElementById('usrPwdMsg').innerHTML=" ";
		flag=true;
	}
	
	return flag;
}