package com.cg.service;

import java.util.List;

import com.cg.entities.Inventory;

public interface ICapgService {

	// List<QueryAnswers> getall();
void plp();

void save(Inventory inventory);

String find(int i);

String retrievePassword(String emailId);
}
