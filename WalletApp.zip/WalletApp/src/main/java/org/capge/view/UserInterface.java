package org.capge.view;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.capge.model.Account;
import org.capge.model.Customer;
import org.capge.util.AccountType;

public class UserInterface {
	private Scanner sc=new Scanner(System.in);
	public int chooseCustomer(List<Customer> customers) {
		for(Customer customer:customers) {
			System.out.println(customer);
		}
		System.out.println("Choose a customer id");
		int customerid=sc.nextInt();
		return customerid;
	}
	public int showMenu() {
		System.out.println("1.Create account\n2.Show all accounts\n3.Transcations\n4.Exit");
		int choice=sc.nextInt();
		return choice;
	}
	public int showSubMenu() {
		System.out.println("1.Debit\n2.Credit\n3.Fund transfer\n4.Exit");
		int subChoice=sc.nextInt();
		return subChoice;
	}
	/*public AccountType acceptAccountType() {
		AccountType accounttype = null;
		while(true) {
			System.out.println("Enter accounttype");
			String acctype = sc.next().toUpperCase();
			try {
				accounttype = AccountType.valueOf(acctype);
				break;
			} catch (Exception e) {
				System.out.println("Enter correct account type");
			}
		}
		return accounttype;
	}
	public double getOpeningBalance() {
		System.out.println("Enter your opening balance");
		double balance=sc.nextDouble();
		return balance;
	}
	public String getDescription() {
		System.out.println("Enter account description");
		String description=sc.next();
		System.out.println("Account created");
		return description;
	}*/
	public double enterAmount() {
		System.out.println("Enter amount");
		double amount=sc.nextDouble();
		return amount;
	}
	public void display(double amount) {
		System.out.println("your balance is "+amount);
		
	}
	public void displayAccountNo(long accountNo) {
		System.out.println("Account created");
		System.out.println("your account number is "+accountNo);
	}
	public long enterAccountno() {
		System.out.println("enter account number");
		long accno=sc.nextLong();
		return accno;
	}
	public Account getAccountDetails() {
		Account acc=new Account();
		AccountType accounttype = null;
		boolean flag=false;
		do {flag=false;
			for(AccountType type:AccountType.values()) {
				System.out.println(type.getValue()+" "+type);	
			}
			int choice=sc.nextInt();
			switch(choice) {
			case 1:accounttype=AccountType.SAVINGS;
			break;
			case 2:accounttype=AccountType.CURRENT;
			break;
			case 3:accounttype=AccountType.RD;
			break;
			case 4:accounttype=AccountType.FD;
			break;
			default:flag=true;
			}
		}while(flag);
		System.out.println("Enter your opening balance");
		double balance=sc.nextDouble();
		System.out.println("Enter account description");
		String description=sc.next();
		acc.setAccountType(accounttype);
		acc.setDescription(description);
		acc.setOpeningBalance(balance);
		return acc;
	}
	
}
