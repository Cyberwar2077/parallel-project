package org.cap.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Customer;

public class CustomerDaoImpl implements ICustomerDao {

	@Override
	public boolean createCustomer(Customer customer) {
		
		EntityManager entityManager= getEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
			entityManager.persist(customer.getAddress());
			entityManager.persist(customer);
		
		transaction.commit();
		entityManager.close();
		
		if(customer.getCustomerId()>0)
			return true;
		return false;
	}

	
	private EntityManager getEntityManager() {
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("jpademo");
		return emf.createEntityManager();
	}
}
