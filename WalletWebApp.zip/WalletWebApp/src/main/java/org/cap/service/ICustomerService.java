package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public interface ICustomerService {
	public boolean createCustomer(Customer customer);

	public Customer findCustomer(Integer custId);

	public boolean createAccount(Account acc);
	public Customer isValid(Customer detail);

	public List<Account> getAccounts(Integer custId);

	public Account findAccount(Long accountId);

	public boolean createTranscation(Transaction transaction);

	public List<Transaction> getAccountTranscations(Long accountId);
}
