package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.CapgDAO;
import com.cg.entities.Inventory;

@Service
@Transactional
public class CapgServiceImpl implements ICapgService {

	@Autowired
	CapgDAO iQueryDAO;
	
	@Override
	public void plp() {
		iQueryDAO.plp();
	}

	@Override
	public void save(Inventory inventory) {
		iQueryDAO.save(inventory);
		
	}

	@Override
	public String find(int i) {
		return iQueryDAO.find(i);
	}

	@Override
	public String retrievePassword(String emailId) {
		return iQueryDAO.retrievePassword(emailId);
	}

	
}
