package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.BillDetails;
import com.cg.entities.Consumer;
import com.cg.service.CustomerService;
import com.sun.org.apache.xml.internal.security.Init;



@Controller
public class EmployeeController {
	
	
	@Autowired
	CustomerService customerService; 
	
	@RequestMapping("/index")
	public String getHomePage(Model model) {
	
		return "index";
	}
	
	@RequestMapping("/Show_ConsumerList")
	public String getAllConsumers(Model model) {
		List<Consumer>consumers=customerService.getAllConsumers();
		model.addAttribute("consumers", consumers);
		return "Show_ConsumerList";
	}
	
	@RequestMapping("/Show_Bills")
	public String Show_Bills(@RequestParam("id") String id,Model model) {
		List<BillDetails> billDetails=customerService.getAllBills(Integer.parseInt(id));
		model.addAttribute("bills",billDetails);
		model.addAttribute("id", id);
		return "Show_Bills";
	}
	
	@RequestMapping("/Generate_bill")
	public String Generate_bill(@RequestParam("id") String id,Model model) {
		model.addAttribute("id", id);
		return "Generate_bill";
	}
	
	@RequestMapping("/Search_Consumer")
	public String Search_Consumer() {
		return "Search_Consumer";
	}
	
	@RequestMapping("/Show_Consumer")
	public String Show_Consumer(@RequestParam("custid") String id,Model model) {
		Consumer consumer=customerService.getConsumer(Integer.parseInt(id));
		model.addAttribute("consumer", consumer);
		return "Show_Consumer";
	}
	
	@RequestMapping("/Bill_Info")
	public String Bill_Info(Model model,@RequestParam("id")String id,@RequestParam("lmonth")String lmonth,@RequestParam("cmonth") String cmonth) {
		double unitconsumed=(Double.parseDouble(cmonth))-(Double.parseDouble(lmonth));
		double netamount=unitconsumed*1.15+100;
		BillDetails billDetails=new BillDetails();
		billDetails.setConsumer_num(Integer.parseInt(id));
		billDetails.setCur_reading(Double.parseDouble(cmonth));
		billDetails.setNetamount(netamount);
		billDetails.setUnitconsumed(unitconsumed);
		model.addAttribute("bill",billDetails);
		Consumer consumer=customerService.getConsumer(Integer.parseInt(id));
		model.addAttribute("consumer", consumer);
		boolean flag=customerService.saveBill(billDetails);
		return "Bill_Info";
	}
	
}
