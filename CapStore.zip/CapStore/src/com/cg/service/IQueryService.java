package com.cg.service;

import java.util.List;

public interface IQueryService {

	// List<QueryAnswers> getall();
void plp();
}
