package com.cg.service;

import com.cg.entities.BookDetails;

public interface IBookServices {

	public void createBook(BookDetails bookDetails);

	public void updateBook(BookDetails newBookDetails);

	public BookDetails displayBookDetails(BookDetails bookDetails);

	public void tableCreation();

}
