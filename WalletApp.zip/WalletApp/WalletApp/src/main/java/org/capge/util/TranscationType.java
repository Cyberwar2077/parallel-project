package org.capge.util;

public enum TranscationType {
	DEBIT,CREDIT
}
