package plp;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Mainclass {
 public static void main(String[] args) {
	 EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		
     transaction.begin();
     
     Admin admin=new Admin("griet", "griet@gmail.com", "asdd", 20.0);
     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre", 1540.45);
     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00, 0.00);
     merchant.setInventory(inventory);
     //customer.setCart(inventory);
     //customer.setWishList(inventory);
     entityManager.persist(admin);
     entityManager.persist(inventory);
     entityManager.persist(merchant);
     entityManager.persist(customer);
     transaction.commit();
     entityManager.close();
}
}
