package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.BillDetails;
import com.cg.entities.Consumer;



@Repository
public class CustomerRepositoryImpl implements CustomerRepository{

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Consumer> getAllConsumers() {
TypedQuery<Consumer> query=	entityManager.createQuery("select e from Consumer e",Consumer.class);
		
		return query.getResultList();
	}

	@Override
	public List<BillDetails> getAllBills(int id) {
		TypedQuery<BillDetails> query=	entityManager.createQuery("select e from BillDetails e where e.consumer_num="+id,BillDetails.class);
		return query.getResultList();
	}

	@Override
	public Consumer getConsumer(int id) {
		
		return entityManager.find(Consumer.class,id);
	}

	@Override
	public boolean saveBill(BillDetails billDetails) {
		entityManager.persist(billDetails);
		entityManager.flush();
		return true;
	} 
	
	
}
