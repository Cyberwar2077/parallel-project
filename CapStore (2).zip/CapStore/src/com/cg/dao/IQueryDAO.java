package com.cg.dao;


public interface IQueryDAO {
	
	void plp();
}
