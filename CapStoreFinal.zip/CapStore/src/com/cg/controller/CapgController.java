package com.cg.controller;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cg.entities.Inventory;
import com.cg.service.ICapgService;

@Controller
public class CapgController {
	
	@Autowired
	ICapgService iQueryService;
	
	@RequestMapping("/index")
	public String index(Model model) {
		iQueryService.plp();
		return "index";
	}
	
	@RequestMapping("/doUpload")
	public String fileupload(@RequestParam CommonsMultipartFile[] fileUpload) {
		 if (fileUpload != null && fileUpload.length > 0) {
	           for (CommonsMultipartFile aFile : fileUpload){  
	                System.out.println("Saving file: " + aFile.getOriginalFilename());
	                Inventory inventory=new Inventory();
	                inventory.setFileName(aFile.getOriginalFilename());
	 	           File convFile = new File(aFile.getOriginalFilename());
	 	           try {
					aFile.transferTo(convFile);
				} catch (Exception e) {
					e.printStackTrace();
				}
	 	          if(convFile.renameTo(new File("C:\\Users\\BBUDDI\\workspace\\CapStore\\WebContent\\images\\" + convFile.getName()))){
	 	     		System.out.println("File is moved successful!");
	 	     	   }else{
	 	     		System.out.println("File is failed to move!");
	 	     	   }
	                iQueryService.save(inventory);              
	            }
	        }
		return "view1";
	}
	
	@RequestMapping("/view")
	public String getFile(Model model,@RequestParam("s") int i) {
		String filepath=iQueryService.find(i);
		System.out.println(filepath);
		model.addAttribute("filepath",filepath);
		return "view";
	}
	
	@RequestMapping("/retrieve")
	public String retrievePassword(Model model,@RequestParam("emailId")String emailId) {
		String password=iQueryService.retrievePassword(emailId);
		model.addAttribute("password", password);
		System.out.println(password);
		return "index";
	}
	
	@RequestMapping("/change")
	public String changePassword(Model model,@RequestParam("previous_password")String password,
			@RequestParam("updated_password") String updatedPassword) {
		
		
		return "index";
	}
}
