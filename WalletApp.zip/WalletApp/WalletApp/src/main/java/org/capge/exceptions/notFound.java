package org.capge.exceptions;

public class notFound extends RuntimeException {
	public notFound(String s){
		super(s);
	}
}
