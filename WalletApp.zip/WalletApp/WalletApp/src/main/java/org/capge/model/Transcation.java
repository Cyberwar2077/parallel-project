package org.capge.model;

import java.time.LocalDate;

import org.capge.util.TranscationType;

public class Transcation {
	private int transcationId;
	private LocalDate transcationDate;
	private TranscationType transcationType;
	private double amount;
	private String description;
	private Account fromAccount;
	private Account toAccount;
	
	public Transcation() {
		
	}
	
	public Transcation(int transcationId, LocalDate transcationDate, TranscationType transcationType, double amount,
			String description, Account fromAccount, Account toAccount) {
		super();
		this.transcationId = transcationId;
		this.transcationDate = transcationDate;
		this.transcationType = transcationType;
		this.amount = amount;
		this.description = description;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
	}
	
	public int getTranscationId() {
		return transcationId;
	}
	public void setTranscationId(int transcationId) {
		this.transcationId = transcationId;
	}
	public LocalDate getTranscationDate() {
		return transcationDate;
	}
	public void setTranscationDate(LocalDate transcationDate) {
		this.transcationDate = transcationDate;
	}
	public TranscationType getTranscationType() {
		return transcationType;
	}
	public void setTranscationType(TranscationType transcationType) {
		this.transcationType = transcationType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Account getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(Account fromAccount) {
		this.fromAccount = fromAccount;
	}
	public Account getToAccount() {
		return toAccount;
	}
	public void setToAccount(Account toAccount) {
		this.toAccount = toAccount;
	}

	@Override
	public String toString() {
		return "Transcation [transcationId=" + transcationId + ", transcationDate=" + transcationDate
				+ ", transcationType=" + transcationType + ", amount=" + amount + ", description=" + description + "]";
	}
	
	
	
}
