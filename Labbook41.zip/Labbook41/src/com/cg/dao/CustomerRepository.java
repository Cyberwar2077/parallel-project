package com.cg.dao;

import java.util.List;

import com.cg.entities.BillDetails;
import com.cg.entities.Consumer;


public interface CustomerRepository {

	List<Consumer> getAllConsumers();

	List<BillDetails> getAllBills(int id);
	
}
