package com.capge.dao;

import com.capge.model.Loginpojo;

public interface ILogindao {
	public boolean isValidLogin(Loginpojo loginPojo);
}
