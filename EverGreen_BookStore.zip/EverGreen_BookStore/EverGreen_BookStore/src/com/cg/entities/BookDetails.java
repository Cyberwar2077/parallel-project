package com.cg.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BookDetails {
	@Id
	private int bookId;
	private Date publishDate;
	private int isbnNumber;
	private String title;
	private String author;
	//private float rating;
	//private int numberOfReviews;
	private float price;
	private String bookImage;
	private String description;
	private CategoryDetails category;
	
	public CategoryDetails getCategoryDetails(){
		return CategoryDetails;
	}
	public void getCategoryDetails(CategoryDetails category){
		this.category=category;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	//public float getRating() {
	//	return rating;
	//}
	//public void setRating(float rating) {
		//this.rating = rating;
	//}
	//public int getNumberOfReviews() {
		//return numberOfReviews;
	//}
	//public void setNumberOfReviews(int numberOfReviews) {
		//this.numberOfReviews = numberOfReviews;
	//}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getBookImage() {
		return bookImage;
	}
	public void setBookImage(String bookImage) {
		this.bookImage = bookImage;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public BookDetails() {
		super();
	}

}
