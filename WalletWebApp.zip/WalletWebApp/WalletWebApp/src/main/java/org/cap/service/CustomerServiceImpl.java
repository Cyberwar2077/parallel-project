package org.cap.service;

import org.cap.dao.CustomerDaoImpl;
import org.cap.dao.ICustomerDao;
import org.cap.model.Customer;

public class CustomerServiceImpl implements ICustomerService {

	private ICustomerDao customerDao;
	
	public CustomerServiceImpl() {
		customerDao=new CustomerDaoImpl();
	}
	
	@Override
	public boolean createCustomer(Customer customer) {
		
		return customerDao.createCustomer(customer);
	}

}
