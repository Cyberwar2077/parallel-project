package org.capge.service;

import java.util.List;

import org.capge.model.Account;
import org.capge.model.Customer;
import org.capge.util.AccountType;

public interface IAccountService {
	public List<Customer> getAllCustomer();

	public boolean validateCustomer(int customerId);

	public long createAccount(Account acc,int customerId);
	public Customer getCustomer(int customerId);

	public double deposit(int customerId, double depositAmount,long accno);

	public double withdraw(int customerId, double withdrawAmount,long accno);
	public void showAccounts(int customerId);
}
