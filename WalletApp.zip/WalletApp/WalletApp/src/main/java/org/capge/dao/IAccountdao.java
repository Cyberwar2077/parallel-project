package org.capge.dao;

import java.util.List;

import org.capge.model.Customer;

public interface IAccountdao {
	public List<Customer> getAllCustomer();
	public boolean validateCustomer(int customerId);
	public Customer getCustomer(int customerId);
}
