package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entities.BookDetails;
import com.cg.service.IBookServices;

@Controller

public class BookController {
	
	@Autowired
	IBookServices iBookServices;
	
	@RequestMapping("/index")			
	public String index() {
		iBookServices.tableCreation();
		return "index";
	}
	
	@RequestMapping("/new_book")
	void createBook(@ModelAttribute("newBookDetails") BookDetails bookDetails){
		iBookServices.createBook(bookDetails);
	}
	
	@RequestMapping("/dispaly_book_details")
	void displayBookDetails(@ModelAttribute("newBookDetails") BookDetails bookDetails){
		BookDetails oldBookDetails=iBookServices.displayBookDetails(bookDetails);
	}
	
	@RequestMapping("/update_book")
	void updateBook(@ModelAttribute("newBookDetails") BookDetails newBookDetails){
		iBookServices.updateBook(newBookDetails);
	}
}
