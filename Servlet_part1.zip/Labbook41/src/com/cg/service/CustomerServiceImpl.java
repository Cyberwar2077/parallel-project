package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.CustomerRepository;
import com.cg.entities.BillDetails;
import com.cg.entities.Consumer;
@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public List<Consumer> getAllConsumers() {
		return customerRepository.getAllConsumers();
	}

	@Override
	public List<BillDetails> getAllBills(int id) {
		return customerRepository.getAllBills(id);
	}

	@Override
	public Consumer getConsumer(int id) {
		return customerRepository.getConsumer(id);
	}

	@Override
	public boolean saveBill(BillDetails billDetails) {
		return customerRepository.saveBill(billDetails);
	} 
	
	

	
}
