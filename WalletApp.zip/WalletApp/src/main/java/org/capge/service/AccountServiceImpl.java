package org.capge.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.capge.dao.AccountDaoImpl;
import org.capge.dao.IAccountdao;
import org.capge.exceptions.notFound;
import org.capge.model.Account;
import org.capge.model.Customer;
import org.capge.util.AccountType;

public class AccountServiceImpl implements IAccountService {
	private static IAccountdao accountDao=new AccountDaoImpl();
	
	
	@Override
	public List<Customer> getAllCustomer() {
		return accountDao.getAllCustomer();
	}
	@Override
	public boolean validateCustomer(int customerId) {
		return accountDao.validateCustomer(customerId);
	}
	@Override
	public long createAccount(Account acc,int customerId) {
		long accountNo=(long)(Math.random()*100000);
		LocalDate openingDate=LocalDate.now();
		Customer customer=getCustomer(customerId);
		acc.setAccountNo(accountNo);
		acc.setCustomer(customer);
		acc.setOpeningDate(openingDate);
		customer.setAccounts(acc);
		return accountNo;
	}
	@Override
	public Customer getCustomer(int customerId) {
		return accountDao.getCustomer(customerId);
	}
	public void showAccounts(int customerId) {
		Customer customer=getCustomer(customerId);
		List<Account>accounts=customer.getAccounts();
		for(Account account:accounts)
			System.out.println(account);
	}
	@Override
	public double deposit(int customerId,double amount,long accno) {
			Customer customer=getCustomer(customerId);
			ArrayList<Account> account=(ArrayList<Account>) customer.getAccounts();
			Account acc1 = null;
			if(account.size()==0) {
				throw new notFound("Please open an account first");
			}
			for(Account acc:account) {
				if(acc.getAccountNo()==accno) {
					acc1=acc;
					break;
				}
				
			}
			if(acc1!=null) {
			acc1.setOpeningBalance(acc1.getOpeningBalance()+amount);
			return acc1.getOpeningBalance();
			}
			else
				throw new notFound("Account number doesn't exits");
			
	}
	@Override
	public double withdraw(int customerId, double withdrawAmount,long accno) {
			Customer customer=getCustomer(customerId);
			ArrayList<Account> account=(ArrayList<Account>) customer.getAccounts();
			if(account.size()==0) {
				throw new notFound("Please open an account first");
			}
			Account acc1 = null;
			for(Account acc:account) {
				if(acc.getAccountNo()==accno) {
					acc1=acc;
					break;
				}
			}
			if(acc1!=null) {
			if(acc1.getOpeningBalance()-withdrawAmount>0) 
				acc1.setOpeningBalance(acc1.getOpeningBalance()-withdrawAmount);
			else
				System.out.println("Minimum balance should be maintained");
			return acc1.getOpeningBalance();
			}
			else 
				throw new notFound("Account number doesn't exits");
	}
	
	
}
