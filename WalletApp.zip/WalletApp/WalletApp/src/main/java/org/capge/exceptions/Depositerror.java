package org.capge.exceptions;

public class Depositerror  extends RuntimeException {
		public Depositerror(String s){
			super(s);
		}
	}

