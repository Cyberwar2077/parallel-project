package org.capge.exceptions;

public class Withdrawerror extends RuntimeException {
		public Withdrawerror(String s){
			super(s);
		}
	}

