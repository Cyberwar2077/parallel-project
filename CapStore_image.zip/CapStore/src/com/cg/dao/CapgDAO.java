package com.cg.dao;

import com.cg.entities.Inventory;

public interface CapgDAO {
	
	void plp();

	void save(Inventory inventory);

	String find(int i);
}
