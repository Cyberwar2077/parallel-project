package com.cg.entities;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class SoldItems implements Serializable{

	@Id
	@GeneratedValue
	private int soldItemId;
	@OneToOne
	@JoinColumn(name="customer")
	private Customer customer;
	@OneToOne
	@JoinColumn(name="inventory")
	private Inventory inventory;
	private String feedback;
	private Date soldDate;
	private byte returned;
	private Date returnedDate;
	private Double price;
	private String reasonForReturning;
	
	
	public String getReasonForReturning() {
		return reasonForReturning;
	}
	public void setReasonForReturning(String reasonForReturning) {
		this.reasonForReturning = reasonForReturning;
	}
	public byte getReturned() {
		return returned;
	}
	public byte isReturned() {
		return returned;
	}
	public void setReturned(byte returned) {
		this.returned = returned;
	}
	public Date getReturnedDate() {
		return returnedDate;
	}
	public void setReturnedDate(Date returnedDate) {
		this.returnedDate = returnedDate;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public int getSoldItemId() {
		return soldItemId;
	}
	public void setSoldItemId(int soldItemId) {
		this.soldItemId = soldItemId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Inventory getInventory() {
		return inventory;
	}
	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public Date getSoldDate() {
		return soldDate;
	}
	public void setSoldDate(Date soldDate) {
		this.soldDate = soldDate;
	}
	
	public SoldItems( String feedback, Date soldDate,
			byte returned, Date returnedDate, Double price,String reasonForReturning) {
		super();
		this.reasonForReturning=reasonForReturning;
		this.feedback = feedback;
		this.soldDate = soldDate;
		this.returned = returned;
		this.returnedDate = returnedDate;
		this.price = price;
	}
	public SoldItems() {
		super();
	}
	
	
}
