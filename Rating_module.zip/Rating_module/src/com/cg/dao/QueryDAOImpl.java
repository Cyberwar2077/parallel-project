package com.cg.dao;




import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

import com.cg.entities.SoldItems;

@Repository
public class QueryDAOImpl implements IQueryDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd", 20.0);
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre", 1540.45);
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00, 0.00);
	     inventory.setMerchant(merchant);
	     SoldItems soldItems=new SoldItems(customer,inventory,"satisfactorcy",new Date());
	   //  soldItems.setInventory(inventory);
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	     entityManager.persist(customer);
	     entityManager.persist(soldItems);
	     entityManager.flush();
		
	}



	@Override
	public Inventory search(int x) {

		 	return	entityManager.find(Inventory.class,x );
	}



	@Override
	public Inventory save(Double x,int y) {
		Inventory inventory1=entityManager.find(Inventory.class,y);
		inventory1.setRating(x);
		return inventory1;
		
		//inventory1.setRating((inventory.getRating()));

	}

	
}
