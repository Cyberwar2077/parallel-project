package com.cg.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CategoryDetails {
	@Id
	@GeneratedValue
	private int categoryId;
	//Unique
	private String categoryName;
	
	public int getcategoryId() {
		return categoryId;
	}
	public void setcategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getcategoryName() {
		return categoryName;
	}
	public void setcategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	public CategoryDetails() {
		super();
	}

}
