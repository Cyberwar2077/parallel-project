package com.cg.dao;

import com.cg.entities.BookDetails;

public interface IBookDao {

	void createBook(BookDetails bookDetails);

	void updateBook(BookDetails newBookDetails);

	BookDetails displayBookDetails(BookDetails bookDetails);

	void tableCreation();

}
