package org.capge.exceptions;

public class customerIdNotFound extends Exception {
	public customerIdNotFound(String s){
		super(s);
	}
}
