package org.capge.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.capge.dao.AccountDaoImpl;
import org.capge.dao.IAccountdao;
import org.capge.exceptions.Depositerror;
import org.capge.exceptions.Withdrawerror;
import org.capge.exceptions.notFound;
import org.capge.model.Account;
import org.capge.model.Customer;
import org.capge.model.Transcation;
import org.capge.util.AccountType;
import org.capge.util.TranscationType;

public class AccountServiceImpl implements IAccountService {
	private static IAccountdao accountDao=new AccountDaoImpl();
	
	
	@Override
	public List<Customer> getAllCustomer() {
		return accountDao.getAllCustomer();
	}
	@Override
	public boolean validateCustomer(int customerId) {
		return accountDao.validateCustomer(customerId);
	}
	@Override
	public long createAccount(Account acc,int customerId) {
		long accountNo=(long)(Math.random()*100000);
		LocalDateTime openingDate=LocalDateTime.now();
		Customer customer=getCustomer(customerId);
		acc.setAccountNo(accountNo);
		acc.setCustomer(customer);
		acc.setOpeningDate(openingDate);
		customer.setAccounts(acc);
		return accountNo;
	}
	@Override
	public Customer getCustomer(int customerId) {
		return accountDao.getCustomer(customerId);
	}
	public void showAccounts(int customerId) {
		Customer customer=getCustomer(customerId);
		List<Account>accounts=customer.getAccounts();
		for(Account account:accounts)
			System.out.println(account);
	}
	public void deleteTransactions(int customerId,long accno) {
		Customer customer=getCustomer(customerId);
		List<Account>accounts=customer.getAccounts();
		Account a = null;
		for(Account account:accounts)
			if(accno==account.getAccountNo()) 
			{
				a=account;
				break;
			}
		a.deleteTranscations();
	}
	@Override
	public double deposit(int customerId,double amount,long accno,String desc) {
			Customer customer=getCustomer(customerId);
			ArrayList<Account> account=(ArrayList<Account>) customer.getAccounts();
			Account acc1 = null;
			if(account.size()==0) {
				throw new Depositerror("Please open an account first");
			}
			for(Account acc:account) {
				if(acc.getAccountNo()==accno) {
					acc1=acc;
					break;
				}
				
			}
			if(acc1!=null) {
			acc1.setOpeningBalance(acc1.getOpeningBalance()+amount);
			if(desc!=null) {
				int transcationId=(int)(Math.random());
				Transcation transcation=new Transcation(transcationId, LocalDate.now(), TranscationType.CREDIT, amount,desc , null, acc1);
				acc1.setTrancations(transcation);
			}
			return acc1.getOpeningBalance();
			}
			else
				throw new Depositerror("Account number doesn't exits");
			
	}
	@Override
	public double withdraw(int customerId, double withdrawAmount,long accno,String desc) {
			Customer customer=getCustomer(customerId);
			ArrayList<Account> account=(ArrayList<Account>) customer.getAccounts();
			if(account.size()==0) {
				throw new Withdrawerror("Please open an account first");
			}
			Account acc1 = null;
			for(Account acc:account) {
				if(acc.getAccountNo()==accno) {
					acc1=acc;
					break;
				}
			}
			if(acc1!=null) {
			if(acc1.getOpeningBalance()-withdrawAmount>0) 
			{ 
				acc1.setOpeningBalance(acc1.getOpeningBalance()-withdrawAmount);
				if(desc!=null) {
					int transcationId=(int)(Math.random());
					Transcation transcation=new Transcation(transcationId, LocalDate.now(), TranscationType.DEBIT, withdrawAmount,desc , null, acc1);
					acc1.setTrancations(transcation);
				}
				return acc1.getOpeningBalance();
			}
			else {
				throw new Withdrawerror("Minimum balance should be maintained");
			}
			
			}
			else 
				throw new Withdrawerror("Account number doesn't exits");
	}
	
	
}
