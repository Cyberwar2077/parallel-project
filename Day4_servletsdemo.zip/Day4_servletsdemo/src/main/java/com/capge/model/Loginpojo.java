package com.capge.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Loginpojo {
	@Id
	@GeneratedValue
	private int userId;
	private String username;
	private String userpwd;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpwd() {
		return userpwd;
	}
	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}
	public Loginpojo(String username, String userpwd) {
		super();
		this.username = username;
		this.userpwd = userpwd;
	}
	public Loginpojo() {
		super();
	}
	
	
}
