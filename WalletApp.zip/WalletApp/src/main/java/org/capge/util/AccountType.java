package org.capge.util;

public enum AccountType {
	SAVINGS(1),CURRENT(2),RD(3),FD(4);
	private int value;
	private AccountType(int value) {
		this.value=value;
	}
	public int getValue() {
		return value;
	}
	
}
