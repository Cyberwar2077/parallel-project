package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;

import oracle.net.aso.i;

@Repository
public class CapgDAOImpl implements CapgDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd");
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre");
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00);
	     //SoldItems items=new SoldItems("erqwr", new Date(), false, null, 120.00);
	     inventory.setMerchant(merchant);
	     customer.setCart(inventory);
	     SoldItems items=new SoldItems();
	     items.setCustomer(customer);
	     items.setInventory(inventory);
	     items.setFeedback("fer");
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	     entityManager.persist(customer);
	     entityManager.persist(items);
	     //entityManager.persist(items);
	     entityManager.flush();
		
	}

	@Override
	public void save(Inventory inventory) {
		entityManager.persist(inventory);
		entityManager.flush();
	}

	@Override
	public String find(int i) {
		Inventory inventory=entityManager.find(Inventory.class,i);
		return inventory.getFileName();
	}

	@Override
	public String retrievePassword(String emailId) {
		//TypedQuery<Admin> query=entityManager.createQuery("select a from Admin a where a.emailId="+emailId, Admin.class);
		String selectQuery = "from Admin a where a.emailId=:emailId";
		Query query = entityManager.createQuery(selectQuery);
		query.setParameter("emailId", emailId);
		List<Admin> admins=query.getResultList();
		return admins.get(0).getPassword();
	}

	
}
