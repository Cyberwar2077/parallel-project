package com.capge.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capge.model.Loginpojo;
import com.capge.service.ILoginservice;
import com.capge.service.LoginserviceImpl;

@WebServlet("/Loginservlet")
public class Loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static ILoginservice service=new LoginserviceImpl();
    
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userName=request.getParameter("username");
		String userpwd=request.getParameter("password");
		Loginpojo details=new Loginpojo(userName, userpwd);
		if(service.isValid(details)) {
			response.sendRedirect("html/Success.html");
		}
		else {
			response.sendRedirect("index.html");
		}
	}

}
