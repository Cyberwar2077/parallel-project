package com.capge.service;

import com.capge.dao.LogindaoImpl;
import com.capge.model.Loginpojo;

public class LoginserviceImpl implements ILoginservice {
	static LogindaoImpl dao=new LogindaoImpl();
	@Override
	public boolean isValid(Loginpojo detail) {
		if(dao.isValidLogin(detail)) 
			return true;
	
		return false;
}
}