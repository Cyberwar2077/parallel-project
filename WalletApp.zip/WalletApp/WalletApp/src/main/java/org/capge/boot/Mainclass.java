package org.capge.boot;

import java.util.List;
import java.util.Scanner;

import org.capge.exceptions.Depositerror;
import org.capge.exceptions.Withdrawerror;
import org.capge.exceptions.customerIdNotFound;
import org.capge.exceptions.notFound;
import org.capge.model.Account;
import org.capge.model.Customer;
import org.capge.service.AccountServiceImpl;
import org.capge.service.IAccountService;
import org.capge.util.AccountType;
import org.capge.view.UserInterface;

public class Mainclass {
	private static IAccountService accountService=new AccountServiceImpl();
	private static UserInterface ui=new UserInterface();
	private static Scanner sc=new Scanner(System.in);
			
	public static void  main(String args[]) {
		boolean validId;
		List<Customer> customers = accountService.getAllCustomer();
		boolean flag=false;
		do {
			flag=false;
			do {
			int customerId = ui.chooseCustomer(customers);
			validId = accountService.validateCustomer(customerId);
			if (validId) {
				int choice = ui.showMenu();
				if (choice == 1) {
					Account acc=ui.getAccountDetails();
					long accountNo=accountService.createAccount(acc,customerId);
					ui.displayAccountNo(accountNo);
				} 
				else if(choice==2) {
					accountService.showAccounts(customerId);
				}
				else if (choice == 3) {
						int subChoice = ui.showSubMenu();
						if(subChoice==1) {
							try {
								double withdrawAmount=ui.enterAmount();
								long accno=ui.enterAccountno();
								String desc=ui.getDescription();
								double amount=accountService.withdraw(customerId,withdrawAmount,accno,desc);
								ui.display(amount);
							} catch (notFound e) {
								System.out.println(e.getMessage());
							}
						}
						else if(subChoice==2) {
							try {
								double depositAmount=ui.enterAmount();
								long accno=ui.enterAccountno();
								String desc=ui.getDescription();
								double amount=accountService.deposit(customerId,depositAmount,accno,desc);
								ui.display(amount);
							} catch (notFound e) {
								System.out.println(e.getMessage());
							}
						}
						else if(subChoice==3) {
							double transferAmount=ui.enterAmount();
							long accno=ui.enterAccountno();
							int customerId1=0;
							while(true) {
							List<Customer> customers1 = accountService.getAllCustomer();
							customerId1= ui.chooseCustomer(customers1);
							validId = accountService.validateCustomer(customerId1);
							if(validId)break;
							}
							long accno1=ui.enterOtherAccountno();
							String desc=ui.getDescription();
							try {
								double amount=accountService.withdraw(customerId, transferAmount, accno,desc);
								double amount1=accountService.deposit(customerId1, transferAmount, accno1,desc);
								ui.display(amount);
							}
							catch (Withdrawerror e) {
								System.out.println(e.getMessage()+"withdraw");
							}
							catch (Depositerror e) {
								System.out.println(e.getMessage()+"deposit");
								accountService.deposit(customerId, transferAmount, accno,null);
								accountService.deleteTransactions(customerId, accno);
							}
							
						}
						else if(subChoice==4) {
							
							
						}
						else {
							System.exit(0);
						}	
					
				} 
				else {
					System.exit(0);
				}
			} 
			else {
				try {
					throw new customerIdNotFound("customer id not found");
				} catch (customerIdNotFound e) {
					System.out.println(e.getMessage());
				}
			} 
		} while (!validId);
		System.out.println("Do you want to continue? Y|N");
		if(sc.next().toUpperCase().charAt(0)=='Y')
			flag=true;
		else
			System.exit(0);
		}while(flag);
	}
}
