package com.capge.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capge.model.Loginpojo;

public class Mainclass {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transcation=entityManager.getTransaction();
		transcation.begin();
		Loginpojo p=new Loginpojo("bharath", "bha123");
		Loginpojo p1=new Loginpojo("hemanth", "hemanth1");
		Loginpojo p2=new Loginpojo("jack", "jack1234");
		entityManager.persist(p);
		entityManager.persist(p1);
		entityManager.persist(p2);
		transcation.commit();
		entityManager.close();	
	}
}
