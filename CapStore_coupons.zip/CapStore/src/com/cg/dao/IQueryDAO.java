package com.cg.dao;

import java.util.List;

import com.cg.entities.Coupons;



public interface IQueryDAO {
	
	void plp();
	List<Coupons> showCoupons(int couponNumber);
	void find(int couponId);
}
