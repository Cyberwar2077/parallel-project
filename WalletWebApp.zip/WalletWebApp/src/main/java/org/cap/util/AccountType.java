package org.cap.util;



public enum AccountType {
	SAVINGS, CURRENT, RD, FD, LOAN;
	

	
	
}
