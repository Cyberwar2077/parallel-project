package com.cg.service;

import java.util.List;

import com.cg.entities.Inventory;
import com.cg.entities.SoldItems;

public interface IQueryService {

	// List<QueryAnswers> getall();
void plp();
public abstract Inventory search(int x);
Inventory save(Double x,int y);
}
