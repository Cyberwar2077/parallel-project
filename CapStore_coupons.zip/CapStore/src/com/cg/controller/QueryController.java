package com.cg.controller;


import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Coupons;
import com.cg.entities.CustomerCap;

import com.cg.service.IQueryService;

@Controller
public class QueryController {
	
	@Autowired
	IQueryService iQueryService;
	double discount;
	CustomerCap customer;
	/*
	@RequestMapping("/search")
	public String index() {
		
		return "search";
	}*/
	@RequestMapping("/index")
	public String index(Model model) {
		iQueryService.plp();
		/*model.addAttribute("customer", new CustomerCap());
		List<Coupons> list=iQueryService.showCoupons();
		for(Coupons coupons:list)
			System.out.println(coupons);
		model.addAttribute("coupons",list);*/
		return "index";
	}

	
@RequestMapping("/search")
public String search(Model model,@RequestParam("couponNumber")String couponNumber) {

	List<Coupons> query1=iQueryService.showCoupons(Integer.parseInt(couponNumber));
	if(query1.isEmpty()) {
	System.out.println("((((((((((((((((((((((((***********************"+query1);
	String coupon1=(String.valueOf(query1.get(0)));
	int cId=Integer.parseInt(coupon1);
iQueryService.find(cId);
/*	EntityManager em;
	CustomerCap cq=new CustomerCap();
	cq.setCustomerId(5);
	cq.getCoupons().remove(query1.get(0));
	*/
return "search";
	}
	else{
		return "error";
	}
}
}


