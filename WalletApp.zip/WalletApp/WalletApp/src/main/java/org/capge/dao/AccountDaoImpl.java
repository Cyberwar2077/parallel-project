package org.capge.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.capge.model.Address;
import org.capge.model.Customer;

public class AccountDaoImpl implements IAccountdao {
	private static List<Customer> customers=database();
	
	private static List<Customer> database(){
		List<Customer> customers=new ArrayList<Customer>();
		customers.add(new Customer(101,"buddi","bharath","61445141","bharath@gmail.com",LocalDate.of(1928, 9, 1),new Address(10,"5/A","omr food court","hyderabad","500056","telangana")));
		customers.add(new Customer(102,"venky","jerry","464423156","venky@gmail.com",LocalDate.of(1978, 9, 10),new Address(1,"34/A","sai nagar","hyderabad","500090","telangana")));
		customers.add(new Customer(103,"sam","amith","455150564","sam@gmail.com",LocalDate.of(1952, 8, 25),new Address(20,"6","ganesh street","hyderabad","500120","telangana")));
		customers.add(new Customer(104,"jack","john","69878987","jack@gmail.com",LocalDate.of(1947, 7, 20),new Address(53,"100/C","ezhil nagar","hyderabad","500452","telangana")));
		customers.add(new Customer(105,"tom","mahesh","45612154","tom@gmail.com",LocalDate.of(1969, 10, 3),new Address(71,"88/B","omr food court","hyderabad","500012","telangana")));
		
		return customers;
	}
	
	@Override
	public List<Customer> getAllCustomer() {
		return customers;
	}

	@Override
	public boolean validateCustomer(int customerId) {
		for(Customer customer:customers) {
			if(customer.getCustomerId()==customerId)
				return true;
		}
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		for(Customer customer:customers) {
			if(customer.getCustomerId()==customerId)
				return customer;
		}
		return null;
	}

}
