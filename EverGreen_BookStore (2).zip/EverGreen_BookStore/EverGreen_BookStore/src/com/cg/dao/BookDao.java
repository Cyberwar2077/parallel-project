package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entities.BookDetails;
import com.cg.entities.CategoryDetails;

@Repository
public class BookDao implements IBookDao{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public void createBook(BookDetails bookDetails) {
		entityManager.persist(bookDetails);
	}

	@Override
	public void updateBook(BookDetails newBookDetails) {
		entityManager.persist(newBookDetails);
	}

	@Override
	public BookDetails displayBookDetails(BookDetails bookDetails) {
		BookDetails oldBookDetails=entityManager.find(BookDetails.class, bookDetails.getBookId());
		return oldBookDetails;
	}

	@Override
	public void tableCreation() {
		CategoryDetails categoryDetails=new CategoryDetails("sed");
		BookDetails book=new BookDetails(23563,"The Late Nights","Harry",78.90f,"doll","the n",categoryDetails);
		entityManager.persist(categoryDetails);
		entityManager.persist(book);
	}

}
