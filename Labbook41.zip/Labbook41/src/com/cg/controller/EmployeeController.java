package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.BillDetails;
import com.cg.entities.Consumer;
import com.cg.service.CustomerService;



@Controller
public class EmployeeController {
	
	
	@Autowired
	CustomerService customerService; 
	
	@RequestMapping("/index")
	public String getHomePage(Model model) {
	
		return "index";
	}
	
	@RequestMapping("/Show_ConsumerList")
	public String getAllConsumers(Model model) {
		List<Consumer>consumers=customerService.getAllConsumers();
		model.addAttribute("consumers", consumers);
		return "Show_ConsumerList";
	}
	
	@RequestMapping("/Show_Bills")
	public String Show_Bills(@RequestParam("id") String id,Model model) {
		List<BillDetails> billDetails=customerService.getAllBills(Integer.parseInt(id));
		model.addAttribute("bills",billDetails);
		return "Show_Bills";
	}
	
	@RequestMapping("/Generate_bill")
	public String Generate_bill(@RequestParam("id") String id,Model model) {
		
		return "Generate_bill";
	}
	
	
}
