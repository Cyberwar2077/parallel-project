package com.capge.service;

import com.capge.model.Loginpojo;

public interface ILoginservice {
	public boolean isValid(Loginpojo detail);
}
