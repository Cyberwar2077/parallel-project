package org.capge.boot;

import java.util.List;
import java.util.Scanner;

import org.capge.exceptions.customerIdNotFound;
import org.capge.exceptions.notFound;
import org.capge.model.Account;
import org.capge.model.Customer;
import org.capge.service.AccountServiceImpl;
import org.capge.service.IAccountService;
import org.capge.util.AccountType;
import org.capge.view.UserInterface;

public class Mainclass {
	private static IAccountService accountService=new AccountServiceImpl();
	private static UserInterface ui=new UserInterface();
	private static Scanner sc=new Scanner(System.in);
			
	public static void  main(String args[]) {
		boolean validId;
		List<Customer> customers = accountService.getAllCustomer();
		boolean flag=false;
		do {
			flag=false;
			do {
			int customerId = ui.chooseCustomer(customers);
			validId = accountService.validateCustomer(customerId);
			if (validId) {
				int choice = ui.showMenu();
				if (choice == 1) {
					/*AccountType accountType=ui.acceptAccountType();
					Double balance=ui.getOpeningBalance();
					String description=ui.getDescription();*/
					Account acc=ui.getAccountDetails();
					long accountNo=accountService.createAccount(acc,customerId);
					ui.displayAccountNo(accountNo);
				} 
				else if(choice==2) {
					accountService.showAccounts(customerId);
				}
				else if (choice == 3) {
						int subChoice = ui.showSubMenu();
						if(subChoice==1) {
							try {
								double withdrawAmount=ui.enterAmount();
								long accno=ui.enterAccountno();
								double amount=accountService.withdraw(customerId,withdrawAmount,accno);
								if((int)(amount)!=-1&&(int)(amount)!=-2)
									ui.display(amount);
							} catch (notFound e) {
								System.out.println(e.getMessage());
							}
						}
						else if(subChoice==2) {
							try {
								double depositAmount=ui.enterAmount();
								long accno=ui.enterAccountno();
								double amount=accountService.deposit(customerId,depositAmount,accno);
								ui.display(amount);
							} catch (notFound e) {
								System.out.println(e.getMessage());
							}
						}
						else if(subChoice==3) {
							
						}
						else {
							System.exit(0);
						}	
					
				} 
				else {
					System.exit(0);
				}
			} 
			else {
				try {
					throw new customerIdNotFound("customer id not found");
				} catch (customerIdNotFound e) {
					System.out.println(e.getMessage());
				}
			} 
		} while (!validId);
		System.out.println("Do you want to continue? Y|N");
		if(sc.next().toUpperCase().charAt(0)=='Y')
			flag=true;
		else
			System.exit(0);
		}while(flag);
	}
}
