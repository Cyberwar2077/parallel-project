package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Customer;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;

@WebServlet("/Loginservlet")
public class Loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static ICustomerService service=new CustomerServiceImpl();
    
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userName=request.getParameter("userName");
		String userpwd=request.getParameter("userPwd");
		Customer details=new Customer(userName, userpwd);
		Customer cust=service.isValid(details);
		if(cust!=null) {
			HttpSession session=request.getSession();
			session.setAttribute("customerid",cust.getCustomerId());
			response.sendRedirect("pages/mainPage.html");
		}
		else {
			request.getRequestDispatcher("index.html").forward(request, response);
		}
	}

}
