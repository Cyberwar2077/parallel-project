package com.cg.entities;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class SoldItems implements Serializable{

	
	@Id
	@GeneratedValue
	private int soldItemId;
	@OneToOne
	@JoinColumn(name="customer")
	private Customer customer;
	@OneToOne
	@JoinColumn(name="inventory")
	private Inventory inventory;
	private String feedback;
	private Date soldDate=new Date();
	public int getSoldItemId() {
		return soldItemId;
	}
	public void setSoldItemId(int soldItemId) {
		this.soldItemId = soldItemId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Inventory getInventory() {
		return inventory;
	}
	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public Date getSoldDate() {
		return soldDate;
	}
	public void setSoldDate(Date soldDate) {
		this.soldDate = soldDate;
	}
	public SoldItems( Customer customer, Inventory inventory, String feedback, Date soldDate) {
		super();
		this.customer = customer;
		this.inventory = inventory;
		this.feedback = feedback;
		this.soldDate = soldDate;
	}
	public SoldItems() {
		super();
	}
	
	@Override
	public String toString() {
		return "SoldItems [soldItemId=" + soldItemId + ", customer=" + customer + ", inventory=" + inventory
				+ ", feedback=" + feedback + ", soldDate=" + soldDate + "]";
	}
}
