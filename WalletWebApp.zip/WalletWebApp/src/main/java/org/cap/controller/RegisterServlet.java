package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ICustomerService customerService;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		customerService=new CustomerServiceImpl();
		
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String email=request.getParameter("email");
		String mobile=request.getParameter("mobile");
		String dateOfBirth=request.getParameter("dateOfBirth");
		String custPassword=request.getParameter("custPassword");
		String doorNo=request.getParameter("doorNo");
		String streetname=request.getParameter("streetname");
		String city=request.getParameter("city");

		String pincode=request.getParameter("pincode");

		String state=request.getParameter("state");

		Address address=new Address();
		address.setCity(city);
		address.setDoorNo(doorNo);
		address.setPincode(pincode);
		address.setState(state);
		address.setStreetName(streetname);
		
		Customer customer=new Customer();
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setEmailId(email);
		customer.setMobileNo(mobile);
		customer.setCustPassword(custPassword);
		//System.out.println(dateOfBirth);
		String[] dob=dateOfBirth.split("-");
		customer.setDateOfBirth(LocalDate.of(Integer.parseInt(dob[0]),
				Integer.parseInt(dob[1]), Integer.parseInt(dob[2])));
		customer.setAddress(address);
		
		
		if(customerService.createCustomer(customer)) {
			request.getRequestDispatcher("index.html").include(request, response);
			PrintWriter out= response.getWriter();
			out.println("<div style='color:red;'>Customer Saved Successfully!</div>");
			
		}else {
			request.getRequestDispatcher("index.html").include(request, response);
			PrintWriter out= response.getWriter();
			out.println("<div style='color:red;'>Invalid Customer Details!</div>");
			
		}
		
	}

}
