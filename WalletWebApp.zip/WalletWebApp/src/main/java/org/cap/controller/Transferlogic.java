package org.cap.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;
import org.cap.util.TransactionType;


@WebServlet("/Transferlogic")
public class Transferlogic extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static ICustomerService service=new CustomerServiceImpl();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String description=request.getParameter("desc");
		double amount=Double.parseDouble(request.getParameter("amount"));
		String type=request.getParameter("type");
		Long accountId=Long.parseLong(request.getParameter("account"));
		Transaction transaction=new Transaction();
		transaction.setAmount(amount);
		transaction.setDescription(description);
		transaction.setTransactionDate(LocalDate.now());
		Account account=service.findAccount(accountId);
		transaction.setFromAccount(account);
		if(type.equals("withdraw"))
			transaction.setTransactionType(TransactionType.DEBIT);
		else if(type.equals("deposit"))
			transaction.setTransactionType(TransactionType.CREDIT);
		if(service.createTranscation(transaction)) {
			response.sendRedirect("WithdrawDeposit");
			
		}
	}

}
