package org.cap.dao;

import org.cap.model.Customer;

public interface ICustomerDao {

	public boolean createCustomer(Customer customer);
}
