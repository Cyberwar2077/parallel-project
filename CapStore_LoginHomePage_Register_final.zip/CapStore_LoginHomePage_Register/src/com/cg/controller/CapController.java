package com.cg.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.QueryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;
import com.cg.service.IAdminService;
import com.cg.service.ICapStoreService;
import com.cg.service.ICustomerService;
import com.cg.service.IMerchantService;
import com.cg.service.IQueryService;

@Controller
public class CapController  {
	
	@Autowired
	HttpSession session;
	@Autowired
	IQueryService iQueryService;
	@Autowired
	IAdminService iAdminService;
	@Autowired
	IMerchantService iMerchantService;
	@Autowired
	ICustomerService iCustomerService;
	@Autowired
	ICapStoreService iCapStoreService;
	
	ArrayList<String> inventoryTypes=new ArrayList<>( Arrays.asList("phone", "laptop", "watches","clothes") );
	
	@RequestMapping("/index")			
	public String index() {
		//iCapStoreService.tableCreation();
		/*inventoryTypes.add("phone");
		inventoryTypes.add("laptop");
		inventoryTypes.add("watches");
		inventoryTypes.add("clothes");*/
		return "index";					// To AJAYS HomePAge
	}
	
	@RequestMapping("/loginpage")
	public String loginindex(HttpServletRequest request,Model model) {
		if(request.getAttribute("message")!=null)
			model.addAttribute("message", request.getAttribute("message"));
		System.out.println(request.getAttribute("message")+"-------");
		return "loginpage";
	}
	
	@RequestMapping(value="/decidor")
	public String decidor(Model model,@RequestParam("emailId")String emailId, @RequestParam("pass")String password,HttpSession session)
	{	
		String encryptedPassword=null;
		encryptedPassword=encryptPassword(password);
		System.out.println(encryptedPassword);
		System.out.println("Is Admin"+iAdminService.isAdmin(emailId,encryptedPassword));
		System.out.println("Is Merchant"+iMerchantService.isMerchant(emailId,encryptedPassword));
		System.out.println("Is Customer"+iCustomerService.isCustomer(emailId,encryptedPassword));
		
		session.setAttribute("userEmailId",emailId); //Changed 6:18 15Mar
		/*session.setAttribute("customer",iCustomerService.isCustomer(emailId,encryptedPassword));*/
		
		if(iAdminService.isAdmin(emailId, encryptedPassword)!=null)
		{
			model.addAttribute("details",iAdminService.isAdmin(emailId, encryptedPassword));
			session.setAttribute("userId",iAdminService.isAdmin(emailId, encryptedPassword).getAdminId());
			session.setAttribute("user","admin");
			return "adminPage";
		}
		else if(iMerchantService.isMerchant(emailId, encryptedPassword)!=null)
		{
			model.addAttribute("details",iMerchantService.isMerchant(emailId, encryptedPassword));
			session.setAttribute("userId",iMerchantService.isMerchant(emailId, encryptedPassword).getMerchantId());
			session.setAttribute("user", "merchant");
			return "merchantPage";
		}
		else if(iCustomerService.isCustomer(emailId, encryptedPassword)!=null)
		{	
			int custId=iCustomerService.getIdFromEmail(emailId);
			System.out.println("Cust id is"+custId);
			session.setAttribute("custId",custId);
			//model.addAttribute("details",iCustomerService.isCustomer(emailId, encryptedPassword));
			//System.out.println(iCustomerService.isCustomer(emailId, password).getCustomerId());
			session.setAttribute("userId",iCustomerService.isCustomer(emailId, encryptedPassword).getCustomerId());
			session.setAttribute("user", "customer");
			model.addAttribute("customerName",iCustomerService.isCustomer(emailId, encryptedPassword).getCustomerName());
			model.addAttribute("inventory", iMerchantService.getAllInventory());
			model.addAttribute("size",iMerchantService.getAllInventory().size());
			model.addAttribute("inventoryTypes", inventoryTypes);
			return "customerPage";
		}
		else {
			model.addAttribute("error", "invalid username or password");
			return "loginpage";
		}
			
		/*return "decidor";*/
	}
	
	 @RequestMapping("/CustomerRegister")
	public String register(Model model,HttpServletRequest request)
	{
		 System.out.println(request.getAttribute("error"));
		model.addAttribute("customer",new Customer());
		if(request.getAttribute("error")!=null)
		{
			model.addAttribute("error",request.getAttribute("error"));
		}
		return "CustomerRegister";
	}
	@RequestMapping(value="/customersave")
	public String save(@ModelAttribute("customer")@Valid Customer customers,BindingResult result,Model model ) {
		if(result.hasErrors()) {
		return "CustomerRegister";
		}
		else {
		customers.setPassword(encryptPassword(customers.getPassword()));
		System.out.println(customers.getPassword());
		try {
			customers=iQueryService.saveCustomer(customers);
		} catch (ArithmeticException e) {
			model.addAttribute("error", "emailId already present");
			return "CustomerRegister";
		}
		model.addAttribute("message","Registration id is "+customers.getCustomerId()+"\n done successful");
		return "loginpage";
		}
//------------//for Merchant Registration-----------------------------
	}
	@RequestMapping("/MerchantRegister")
	public String merchantRegister(Model model)
	{
		model.addAttribute("merchant", new Merchant());
		return "MerchantRegister";
	}
	
	@RequestMapping(value="/merchantsave")
	public String save1(@ModelAttribute("merchant")@Valid Merchant merchant,BindingResult result,Model model ) {
		if(result.hasErrors()) {
		return "MerchantRegister";
		}
		else {
		merchant.setPassword(encryptPassword(merchant.getPassword()));
		System.out.println(merchant.getPassword());
		try {
			merchant=iQueryService.saveMerchant(merchant);
		} catch (ArithmeticException e) {
			// TODO Auto-generated catch block
			model.addAttribute("error", "emailId already present");
			return "MerchantRegister";
		}
		model.addAttribute("message","Registration id is "+merchant.getMerchantId()+"\n transaction done successful");
		return "loginpage";
		}
	}
	
	@RequestMapping(value="/homePage")
	public String loginsession(Model model) {	
	String user=session.getAttribute("user").toString();
	if(user.equals("customer")) {
		int customerId=(int)session.getAttribute("userId");
		model.addAttribute("emailId",iCustomerService.find(customerId).getEmailId());
		model.addAttribute("pass",decryptPassword(iCustomerService.find(customerId).getPassword()));
		return "redirect:decidor.html";
	}
	if(user.equals("merchant")) {
		int merchantId=(int)session.getAttribute("userId");
		model.addAttribute("emailId",iMerchantService.findMerchant(merchantId).getEmailId());
		model.addAttribute("pass",decryptPassword(iMerchantService.findMerchant(merchantId).getPassword()));
		return "redirect:decidor.html";
	}
	if(user.equals("admin")) {
		model.addAttribute("emailId","aswin@gmail.com");
		model.addAttribute("pass","Admin12");
		return "redirect:decidor.html";
	}
		return "redirect:decidor.html";
	}
	
	@RequestMapping("/forgotPwd")
	public String forgotPassword() {
		return "forgotPassword";
	}
	
	@RequestMapping("/retrievePassword")
	public String retrievePassword(Model model,@RequestParam("emailId")String emailId) {
		String password=null;
		if(iAdminService.getAdminPassword(emailId)!=null)
			password=iAdminService.getAdminPassword(emailId);
		else if(iCustomerService.getCustomerPassword(emailId)!=null)
			password=iCustomerService.getCustomerPassword(emailId);
		else if(iMerchantService.getMerchantPassword(emailId)!=null)
			password=iMerchantService.getMerchantPassword(emailId);
		else
			model.addAttribute("error", "enter valid email id");
		model.addAttribute("password", password);
		System.out.println(password);
		return "forgotPassword";
	}
	
	
	public String encryptPassword(String password) {
		StringBuffer encryptPassword=new StringBuffer();
		int id=1;
		for(int i=0;i<password.length();i++) {
			int ascii=(int)password.charAt(i)+id*i;
			String j=Character.toString((char)ascii);
			encryptPassword.append(j);
		}
		return encryptPassword.toString();
	}
	
	public String decryptPassword(String password) {
		StringBuffer encryptPassword=new StringBuffer();
		int id=1;
		for(int i=0;i<password.length();i++) {
			int ascii=(int)password.charAt(i)-id*i;
			String j=Character.toString((char)ascii);
			encryptPassword.append(j);
		}
		return encryptPassword.toString();
	}
	
	@RequestMapping("/details")
	public String details(Model model,HttpSession session)
	{int merchantId=(int)session.getAttribute("userId");
		model.addAttribute("sample",iMerchantService.showDetails(merchantId));
	return "details";
		}
	
	

@RequestMapping("/myinventory")
public String inventory(Model model,HttpSession session)

{ int merchantId=(int)session.getAttribute("userId");
	List<Inventory> inventories=iMerchantService.loadAll(merchantId);
	for (Inventory inventory : inventories) {
		System.out.println(inventory.getInventoryId()+"     "+inventory.getInventoryName()+"   mID "+inventory.getMerchant().getMerchantId());
	}
	model.addAttribute("inventories",inventories);
	model.addAttribute("size", inventories.size());
		return "myinventory";
	}

@RequestMapping("/removeinventory")
public String inventoryremove(Model model,@RequestParam("inventory")String inventoryId)
{
	System.out.println("controller\n"+inventoryId);
	
	if(iMerchantService.removeInventory(Integer.parseInt(inventoryId)))
	{ 
		System.out.println("Inventory removed successfully");
	}
	
return "redirect:/myinventory.html";
	}

@RequestMapping("/updateinventory")
public String updateInventory(Model model,@RequestParam("inventory")String inventoryId)
{
	Inventory foundInventory=iMerchantService.findInventory(Integer.parseInt(inventoryId));
  
	model.addAttribute("inventory",foundInventory);
	
	
return "updateinventory";
	}


@RequestMapping("/updatedinventory")
public String updateInventory(Model model,HttpSession session,@ModelAttribute("inventory")Inventory inventory,BindingResult bindingResult)
{ 
	int merchantId=(int)session.getAttribute("userId");
Merchant merchant=iMerchantService.findMerchant(merchantId);
inventory.setMerchant(merchant);
  iMerchantService.updateInventory(inventory);
	
return "redirect:/myinventory.html";
	}
@RequestMapping("/addImage")
public String addImage(@RequestParam("inventory")String inventoryId,Model model) {
	
	model.addAttribute("inventoryId", inventoryId);
	
	
	return "uploadImage";
}

@RequestMapping("/doUpload")
public String fileupload(@RequestParam CommonsMultipartFile[] fileUpload,@RequestParam("inventoryId")String inventoryId) {
	 if (fileUpload != null && fileUpload.length > 0) {
           for (CommonsMultipartFile aFile : fileUpload){  
                System.out.println("Saving file: " + aFile.getOriginalFilename());
                
                Inventory inventory=iMerchantService.findInventory(Integer.parseInt(inventoryId));
                
                inventory.setFileName(aFile.getOriginalFilename());
 	           File convFile = new File(aFile.getOriginalFilename());
 	           try {
				aFile.transferTo(convFile);
			} catch (Exception e) {
				e.printStackTrace();
			}
 	          if(convFile.renameTo(new File("C:\\Users\\BBUDDI\\Downloads\\CapStore_LoginHomePage_Register\\WebContent\\images\\" + convFile.getName()))){
 	     		System.out.println("File is moved successful!");
 	     	   }else{
 	     		System.out.println("File is failed to move!");
 	     	   }
 	         iMerchantService.updateInventoryImage(inventory);   
 	          
            }
        }
	 return "redirect:/myinventory.html";
}

@RequestMapping("/addinventory")
public String add(@ModelAttribute("inventory") Inventory inventories,Model model) {
	model.addAttribute("inventory",new Inventory());
	model.addAttribute("inventoryTypes", inventoryTypes);
	return "addinventory";
}
	
@RequestMapping("/addnewinventory")
public String addinventory(@ModelAttribute("inventory") Inventory newinventory,Model model,HttpSession session) {
	
	
	int merchantId=(int)session.getAttribute("userId");
	Merchant merchant=iMerchantService.findMerchant(merchantId);

	newinventory.setMerchant(merchant);
	newinventory.setRating(0.0);
	
	Inventory addedinventory=iMerchantService.addinventory(newinventory);
	model.addAttribute("message","Item with Id"+addedinventory.getInventoryId()+"added succesfully!");
	return "redirect:/myinventory.html";
}


@RequestMapping("/AddDiscount")
public String addDiscount(Model model)

{
return "addDiscount";
	}


@RequestMapping("/DeleteDiscounts")
public String deleteDiscounts(Model model)

{
return "deleteDiscounts";
	}


@RequestMapping("/SoldItems")
public String soldItems(Model model)

{
	int merchantId=(int)session.getAttribute("userId");
	model.addAttribute("solditems",iMerchantService.getAllInventoryOfMerchant(merchantId));
	model.addAttribute("size", iMerchantService.getAllInventoryOfMerchant(merchantId).size());
	List<String> status = new ArrayList<String>();
	status.add("OrderPlaced");
	status.add("packagedDone");
	status.add("Dispatched");
	status.add("Delivered");
	model.addAttribute("status",status);
return "soldItems";
	}

@RequestMapping("/logout")
public String logout(Model model)
{
	session.invalidate();
return "redirect:loginpage.html";
	}	

@RequestMapping("/merchant")
public String showMerchants(Model model) {
	model.addAttribute("merchant", iAdminService.ViewallMerchant());
	model.addAttribute("size",  iAdminService.ViewallMerchant().size());
	return "merchantdetails";
}

@RequestMapping("/inventory")
public String start(Model model) {
	List<Inventory> allInventories=iAdminService.ViewallInventory();
	model.addAttribute("inventory",allInventories) ;
	model.addAttribute("size",allInventories.size() );
	return "inventorydetails";
}

@RequestMapping("/customer")
public String showCustomer(Model model) {
model.addAttribute("customer", iAdminService.ViewallCustomer());
model.addAttribute("size",iAdminService.ViewallCustomer().size() );
return "customerdetails";
}

@RequestMapping("/remove")
public String merchantremove(Model model,@RequestParam("merchant")String mechantId)
{
System.out.println("controller\n"+mechantId);

if(iAdminService.removeMerchant(Integer.parseInt(mechantId)))
{ 
System.out.println("Merchant removed successfully");
}

return "redirect:merchant.html";
}

@RequestMapping("/updateStatus")
public String updateStatus(Model model,HttpServletRequest httpRequest) {
	int merchantId=(int)session.getAttribute("userId");
	List<SoldItems> items=iMerchantService.getAllInventoryOfMerchant(merchantId);
	String[] status=httpRequest.getParameterValues("status");
	System.out.println(status);
	for(int i=0;i<status.length;i++) {
		iMerchantService.updateStatus(merchantId,items.get(i),status[i]);
	}
	return"redirect:SoldItems.html";
}

@RequestMapping("/rating")
public String rating(Model model,@RequestParam("id")String soldId) {
	model.addAttribute("id", soldId);
	return "rateProduct";
}
@RequestMapping("/rated")
public String rated(@RequestParam("rate")String rate,@RequestParam("id")String soldId) {
	iMerchantService.setRating(rate,soldId);
	
	return "redirect:ordereditems.html";
}
}
