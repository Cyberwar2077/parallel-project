package com.cg.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class BillDetails {
	@Id
	@GeneratedValue
	private int bill_num;
	private int consumer_num;
	private double cur_reading;
	private double unitconsumed;
	private double netamount;
	private Date bill_date;
	
	public int getBill_num() {
		return bill_num;
	}
	public void setBill_num(int bill_num) {
		this.bill_num = bill_num;
	}
	public int getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}
	public double getCur_reading() {
		return cur_reading;
	}
	public void setCur_reading(double cur_reading) {
		this.cur_reading = cur_reading;
	}
	public double getUnitconsumed() {
		return unitconsumed;
	}
	public void setUnitconsumed(double unitconsumed) {
		this.unitconsumed = unitconsumed;
	}
	public double getNetamount() {
		return netamount;
	}
	public void setNetamount(double netamount) {
		this.netamount = netamount;
	}
	public Date getBill_date() {
		return bill_date;
	}
	public void setBill_date(Date bill_date) {
		this.bill_date = bill_date;
	}
	public BillDetails(int bill_num, int consumer_num, double cur_reading, double unitconsumed, double netamount,
			Date bill_date) {
		super();
		this.bill_num = bill_num;
		this.consumer_num = consumer_num;
		this.cur_reading = cur_reading;
		this.unitconsumed = unitconsumed;
		this.netamount = netamount;
		this.bill_date = bill_date;
	}
	
}
