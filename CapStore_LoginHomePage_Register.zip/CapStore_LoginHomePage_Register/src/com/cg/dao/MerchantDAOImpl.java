package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;

@Repository
public class MerchantDAOImpl implements IMerchantDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Merchant isMerchant(String userName, String userPassword) {
		
		TypedQuery<Merchant> query=entityManager.createQuery("select a from Merchant a where a.emailId=:eId and a.password=:pwd",Merchant.class);
		query.setParameter("eId",userName);
		query.setParameter("pwd",userPassword);
		List<Merchant> users = query.getResultList();
		//System.out.println(users);
		if(users.size()>0)
			return users.get(0);
		else
			return null; 
		 
	}

	@Override
	public String getMerchantPassword(String userName) {
		TypedQuery<Merchant> query=entityManager.createQuery("select a from Merchant a where a.emailId=:eId",Merchant.class);
		query.setParameter("eId",userName);
		List<Merchant> users = query.getResultList();
		//System.out.println(users);
		if(users.size()>0)
			return users.get(0).getPassword();
		else
			return null; 
	}

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd", 20.0);
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre");
	     Merchant merchant=new Merchant("afefq@gmail.com", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("coolpad", 50, 200.00, "Mobile", 0.00);
	     Inventory inventory1=new Inventory("Redmi", 40, 100.00, "Mobile", 10.00);
	     inventory.setMerchant(merchant);
	     inventory1.setMerchant(merchant);
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	     entityManager.persist(inventory1);
	     entityManager.persist(customer);
	     entityManager.flush();
		
	}



	@Override
	public void viewInventory() {
	
		
	}



	@Override
	public void addProducts() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void removeProduct() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void addDiscount() {
		
		
	}

	@Override
	public void removeDiscount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkOrders() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void promos() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Merchant showDetails(int id) {		
				TypedQuery<Merchant> query=entityManager.createQuery("select s from Merchant s where s.merchantId="+id,Merchant.class);
				return query.getSingleResult();
	}

	@Override
	public List<Inventory> loadAll(int id) {
		// TODO Auto-generated method stub
		TypedQuery<Inventory> query=entityManager.createQuery("select s from Inventory s where s.merchant.merchantId="+id,Inventory.class);
		//query.setParameter("mid", id);
		return query.getResultList();
	}



	@Override
	public boolean removeInventory(int inventorye) {
		Inventory inventoryFound = entityManager.find(Inventory.class, inventorye);
		System.out.println("Inventory found"+inventoryFound);
		if(inventoryFound!=null)
		{
			inventoryFound.setMerchant(null);
			inventoryFound.setQuantity(0);
			return true;
		}else {
		return false;
	}
	}



	@Override
	public Inventory findinventory(int inventoryId) {
		Inventory inventoryFound = entityManager.find(Inventory.class, inventoryId);
		if(inventoryFound!=null) {
			return inventoryFound;
		}
		return inventoryFound;
	}



	@Override
	public Inventory addinventory(Inventory newinventory) {
		System.out.println("added new inventory"+newinventory);
		newinventory.setNoOfRatings(0);
		newinventory.setRating(0.00);
	      entityManager.persist(newinventory);
			entityManager.flush();
			return newinventory;
	}



	@Override
	public Merchant findMerchant(int merchantId) {
Merchant foundMerchant=entityManager.find(Merchant.class, merchantId);
		return foundMerchant;
	}



	@Override
	public void updateInventory(Inventory inventory) {
		Inventory foundinventory=entityManager.find(Inventory.class, inventory.getInventoryId());
		System.out.println("Before update"+foundinventory);
		foundinventory.setDiscount(inventory.getDiscount());
		foundinventory.setPrice(inventory.getPrice());
		foundinventory.setQuantity(inventory.getQuantity());
		
		System.out.println("After update"+foundinventory);
		
	}



	@Override
	public void updateInventoryImage(Inventory inventory) {
		Inventory foundinventory=entityManager.find(Inventory.class, inventory.getInventoryId());
		foundinventory.setFileName(inventory.getFileName());
	}

	@Override
	public List<Inventory> getAllInventory() {
		TypedQuery<Inventory> query=entityManager.createQuery("select s from Inventory s where s.merchant!=null",Inventory.class);
		return query.getResultList();
	}

	@Override
	public List<SoldItems> getAllInventoryOfMerchant(int merchantId) {
		TypedQuery<SoldItems> query=entityManager.createQuery("select s from SoldItems s where s.inventory.merchant.merchantId="+merchantId,SoldItems.class);
		return query.getResultList();
	}

	@Override
	public void updateStatus(int merchantId, SoldItems soldItems, String string) {
		// TODO Auto-generated method stub
		soldItems.setStatus(string);
	}

	@Override
	public void setRating(String rate, String soldId) {
		// TODO Auto-generated method stub
		TypedQuery<SoldItems> query=entityManager.createQuery("select s from SoldItems s where s.soldItemId="+soldId,SoldItems.class);
		SoldItems items=query.getResultList().get(0);
		Double rating=items.getInventory().getRating();
		int noOfRating=items.getInventory().getNoOfRatings();
		int rates=Integer.parseInt(rate);
		Double finalRate=(rating*noOfRating+rates)/(noOfRating+1);
		items.getInventory().setNoOfRatings(noOfRating+1);
		items.getInventory().setRating(finalRate);
	}




}
