package com.cg.dao;

import com.cg.entities.Inventory;
import com.cg.entities.SoldItems;

public interface IQueryDAO {
	
	void plp();

	public abstract Inventory search(int x);

	Inventory save(Double x,int y);
}
