package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Inventory;
import com.cg.entities.SoldItems;
import com.cg.service.IQueryService;



@Controller
public class Rating_controller {
	@Autowired
	IQueryService iQueryService;

	//SoldItems soldItems=new SoldItems(); 
	
	@RequestMapping(value="/index")
	public String pub() {
		iQueryService.plp();
		return "index";
		}
	@RequestMapping(value="/Rate")
	public String rate() {
		return "get";
		
	}
	
	@RequestMapping(value="/get")
	public String get(@RequestParam("rangeInput")String rate,@RequestParam("soldid")String id,Model model) {
		
		iQueryService.save(Double.parseDouble(rate),Integer.parseInt(id));
		System.out.println(	iQueryService.save(Double.parseDouble(rate),Integer.parseInt(id)));
		return "index";
		
		}
	@RequestMapping(value="/soldid")
	public String getid() {
		return "get";
		
	}
	
	@RequestMapping(value="/searchbyid")
	public String sayHellotome(@RequestParam("id")String id,Model model) {
		Inventory inventory=iQueryService.search(Integer.parseInt(id));
		model.addAttribute("id",id);
	model.addAttribute("inventory",inventory);
	//System.out.println(inventory);
	if(inventory==null)
	
	{
		return "get";
	}
	else {
	//	System.out.println(inventory);
		return "rate";
	}

	}
	
}
