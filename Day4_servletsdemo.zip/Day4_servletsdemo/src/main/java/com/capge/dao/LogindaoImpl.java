package com.capge.dao;



	import java.util.List;



	import javax.persistence.EntityManager;

	import javax.persistence.EntityManagerFactory;

	import javax.persistence.EntityTransaction;

	import javax.persistence.Persistence;

	import javax.persistence.Query;

import com.capge.model.Loginpojo;






	public class LogindaoImpl implements ILogindao {



		@Override
		public boolean isValidLogin(Loginpojo loginPojo) {

			

			EntityManager manager=getEntityManagerFactory().createEntityManager();

			EntityTransaction transaction= manager.getTransaction();

			transaction.begin();

			String sql="from Loginpojo lgn where lgn.username=:uName and lgn.userpwd=:uPwd";

			Query query= manager.createQuery(sql);

			query.setParameter("uName", loginPojo.getUsername());

			query.setParameter("uPwd", loginPojo.getUserpwd());

			

			List<Loginpojo> logins= query.getResultList();

			transaction.commit();

			manager.close();

			

			if(logins.size()>0) 

				return true;

			

			return false;

		}



		private EntityManagerFactory getEntityManagerFactory() {

			return Persistence.createEntityManagerFactory("jpademo");

		}

		

}

